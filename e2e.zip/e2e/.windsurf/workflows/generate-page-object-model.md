---
description:
auto_execution_mode: 1
---

Please call the mkr-playwright-mcp to get the current html and screen of visible page. Implement a proper Page Object Model in `pom/pages` folder.
